-- ============================================================
-- NIHSS Driver Booking — Schema v2 (additive migration)
-- Run this AFTER supabase-schema.sql, in the SQL Editor.
-- Everything here is additive/idempotent — safe to run even if
-- some parts already exist.
-- ============================================================

-- ---------- Bookings: destination + reschedule proposal ----------
alter table bookings add column if not exists destination text;
alter table bookings add column if not exists proposed_date date;
alter table bookings add column if not exists proposed_time_leave time;
alter table bookings add column if not exists proposed_time_collect time;
-- status now also supports 'Denied', 'Rescheduled', 'Cancelled' (no schema
-- change needed since status is a free-text column, but the app now writes
-- these instead of the old 'Declined')

-- ---------- Managers: numeric permission level ----------
-- 1 = View Only, 2 = Approver (can accept/deny/reschedule)
alter table managers add column if not exists level int not null default 1;

-- ---------- Report recipients: display name + enable/disable ----------
alter table report_emails add column if not exists name text;
alter table report_emails add column if not exists enabled boolean not null default true;

insert into report_emails (name, email, enabled) values
  ('Admin Manager NIHSS', 'adminmanager.nihss@health.gov.sc', true),
  ('Director NIHSS', 'director.NIHSS@health.gov.sc', true),
  ('Flora Dodo', 'Flora.Dodo@health.gov.sc', true),
  ('Eali', 'eali@health.gov.sc', true),
  ('Saphira Morel', 'saphira.morel@health.gov.sc', true),
  ('Deputy Director NIHSS', 'deputydirector.NIHSS@health.gov.sc', true)
on conflict (email) do nothing;

-- ---------- Audit log ----------
-- Replaces the informal activity_log going forward. IP address is captured
-- client-side via a public "what's my IP" lookup, which is best-effort (it
-- reflects the network the browser is on, not a verified server-side capture).
create table if not exists audit_log (
  id uuid primary key default gen_random_uuid(),
  at timestamptz not null default now(),
  username text,
  full_name text,
  role text,
  ip_address text,
  action text not null,
  status text not null default 'Success',
  details text
);
alter table audit_log enable row level security;
drop policy if exists "anon full access" on audit_log;
create policy "anon full access" on audit_log for all using (true) with check (true);
grant select, insert on audit_log to anon;

-- ---------- Driver management: edit / delete / reset password ----------
create or replace function update_driver(p_id uuid, p_name text, p_contact text, p_vehicle text)
returns void language sql security definer as $$
  update drivers set name = p_name, contact = p_contact, vehicle = p_vehicle where id = p_id;
$$;

create or replace function delete_driver(p_id uuid)
returns void language sql security definer as $$
  delete from drivers where id = p_id;
$$;

create or replace function reset_driver_password(p_id uuid, p_new_password text)
returns void language sql security definer as $$
  update drivers set password = p_new_password where id = p_id;
$$;

grant execute on function update_driver(uuid, text, text, text) to anon;
grant execute on function delete_driver(uuid) to anon;
grant execute on function reset_driver_password(uuid, text) to anon;

-- ---------- Management user management: edit / delete / reset password / level ----------
create or replace function update_manager(p_id uuid, p_name text, p_level int)
returns void language sql security definer as $$
  update managers set name = p_name, level = p_level where id = p_id;
$$;

create or replace function delete_manager(p_id uuid)
returns void language sql security definer as $$
  delete from managers where id = p_id;
$$;

create or replace function reset_manager_password(p_id uuid, p_new_password text)
returns void language sql security definer as $$
  update managers set password = p_new_password where id = p_id;
$$;

grant execute on function update_manager(uuid, text, int) to anon;
grant execute on function delete_manager(uuid) to anon;
grant execute on function reset_manager_password(uuid, text) to anon;

-- ---------- list_managers / authenticate_manager / create_manager now use level ----------
-- Same argument signatures as v1 but different return columns / a new int
-- parameter, so the old versions must be dropped before redefining.
drop function if exists list_managers();
create or replace function list_managers()
returns table(id uuid, name text, username text, level int, active boolean)
language sql security definer as $$
  select id, name, username, level, active from managers order by name;
$$;

drop function if exists authenticate_manager(text, text);
create or replace function authenticate_manager(p_username text, p_password text)
returns table(id uuid, name text, username text, level int)
language sql security definer as $$
  select id, name, username, level from managers
  where username = p_username and password = p_password and active = true;
$$;

create or replace function create_manager(p_name text, p_username text, p_password text, p_level int)
returns void language sql security definer as $$
  insert into managers (name, username, password, level) values (p_name, p_username, p_password, p_level);
$$;

grant execute on function list_managers() to anon;
grant execute on function authenticate_manager(text, text) to anon;
grant execute on function create_manager(text, text, text, int) to anon;

-- ---------- Report recipient management ----------
create or replace function update_report_email(p_id uuid, p_name text, p_email text, p_enabled boolean)
returns void language sql security definer as $$
  update report_emails set name = p_name, email = p_email, enabled = p_enabled where id = p_id;
$$;
grant execute on function update_report_email(uuid, text, text, boolean) to anon;
