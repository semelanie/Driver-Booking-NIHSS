// supabase/functions/monthly-report/index.ts
//
// Generates a PDF summary of the previous month's bookings and emails it to
// every enabled row in report_emails, via Resend.
//
// Deploy:   supabase functions deploy monthly-report
// Secrets:  supabase secrets set RESEND_API_KEY=your_resend_key
//           supabase secrets set SUPABASE_SERVICE_ROLE_KEY=your_service_role_key
// Schedule: In the Supabase SQL Editor, run once (needs the pg_cron and
//           pg_net extensions, enabled by default on most projects):
//
//   select cron.schedule(
//     'nihss-monthly-report',
//     '0 6 1 * *',  -- 06:00 on the 1st of every month
//     $$
//     select net.http_post(
//       url := 'https://ytcsntxpfcursvdmstlb.supabase.co/functions/v1/monthly-report',
//       headers := jsonb_build_object('Authorization', 'Bearer ' || 'YOUR_ANON_OR_SERVICE_KEY')
//     );
//     $$
//   );

import { serve } from "https://deno.land/std@0.203.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { jsPDF } from "https://esm.sh/jspdf@2.5.1";

const SUPABASE_URL = "https://ytcsntxpfcursvdmstlb.supabase.co";
const SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY");
const FROM_ADDRESS = "NIHSS Driver Booking <bookings@your-verified-domain.sc>";

serve(async () => {
  try {
    const sb = createClient(SUPABASE_URL, SERVICE_ROLE_KEY);

    const now = new Date();
    const monthStart = new Date(now.getFullYear(), now.getMonth() - 1, 1).toISOString().slice(0, 10);
    const monthEnd = new Date(now.getFullYear(), now.getMonth(), 0).toISOString().slice(0, 10);

    const { data: bookings, error } = await sb
      .from("bookings")
      .select("*")
      .gte("date", monthStart)
      .lte("date", monthEnd);
    if (error) throw error;

    const { data: recipients } = await sb
      .from("report_emails")
      .select("email")
      .eq("enabled", true);

    const byDept: Record<string, number> = {};
    const byDriver: Record<string, number> = {};
    bookings.forEach((b: any) => {
      byDept[b.dept] = (byDept[b.dept] || 0) + 1;
      if (b.accepted_by) byDriver[b.accepted_by] = (byDriver[b.accepted_by] || 0) + 1;
    });

    // ---- Build the PDF ----
    const doc = new jsPDF();
    const monthLabel = new Date(monthStart).toLocaleDateString("en-GB", { month: "long", year: "numeric" });
    doc.setFontSize(18);
    doc.text("NIHSS Driver Booking — Monthly Report", 14, 20);
    doc.setFontSize(12);
    doc.text(`Period: ${monthLabel}`, 14, 30);
    doc.text(`Generated: ${now.toLocaleString()}`, 14, 37);

    let y = 50;
    doc.setFontSize(14);
    doc.text("Summary", 14, y); y += 8;
    doc.setFontSize(11);
    const total = bookings.length;
    const accepted = bookings.filter((b: any) => b.status === "Accepted").length;
    const denied = bookings.filter((b: any) => b.status === "Denied" || b.status === "Declined").length;
    const rescheduled = bookings.filter((b: any) => b.status === "Rescheduled").length;
    const pending = bookings.filter((b: any) => b.status === "Pending").length;
    [
      `Total booking requests: ${total}`,
      `Accepted: ${accepted}`,
      `Denied: ${denied}`,
      `Rescheduled: ${rescheduled}`,
      `Pending: ${pending}`,
    ].forEach(line => { doc.text(line, 14, y); y += 7; });

    y += 6;
    doc.setFontSize(14);
    doc.text("Most active drivers", 14, y); y += 8;
    doc.setFontSize(11);
    const topDrivers = Object.entries(byDriver).sort((a, b) => (b[1] as number) - (a[1] as number)).slice(0, 5);
    if (topDrivers.length) {
      topDrivers.forEach(([name, count]) => { doc.text(`${name}: ${count} trips`, 14, y); y += 7; });
    } else {
      doc.text("No accepted trips this period.", 14, y); y += 7;
    }

    y += 6;
    doc.setFontSize(14);
    doc.text("Requests by department", 14, y); y += 8;
    doc.setFontSize(11);
    Object.entries(byDept).forEach(([dept, count]) => { doc.text(`${dept}: ${count}`, 14, y); y += 7; });

    const pdfBase64 = doc.output("datauristring").split(",")[1];

    // ---- Email it to every enabled recipient ----
    const results = [];
    for (const r of recipients || []) {
      const res = await fetch("https://api.resend.com/emails", {
        method: "POST",
        headers: { "Authorization": `Bearer ${RESEND_API_KEY}`, "Content-Type": "application/json" },
        body: JSON.stringify({
          from: FROM_ADDRESS,
          to: [r.email],
          subject: `NIHSS Driver Booking — Monthly Report (${monthLabel})`,
          html: `<p>Attached is the driver booking report for ${monthLabel}.</p>`,
          attachments: [{ filename: `nihss-report-${monthStart}.pdf`, content: pdfBase64 }],
        }),
      });
      results.push({ to: r.email, ok: res.ok });
    }

    await sb.from("audit_log").insert({
      action: "Monthly Report Sent",
      status: "Success",
      details: `${monthLabel}: sent to ${results.filter(r => r.ok).length}/${results.length} recipients`,
    });

    return new Response(JSON.stringify({ ok: true, results }), { headers: { "Content-Type": "application/json" } });
  } catch (err) {
    return new Response(JSON.stringify({ error: String(err) }), { status: 500 });
  }
});
